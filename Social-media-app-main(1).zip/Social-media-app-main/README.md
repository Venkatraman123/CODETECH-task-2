# Welcome MERN Social media application ✉️💬👾📺

**SPA Social media application ✉️ 📞 with video and audio calls.**  Social network 🌍 application model. You can share photos and videos 🤳📷. Write messages in real time 💬⏱️. View the feed of people 🧑‍🤝‍🧑  you are interested in.  <a href="https://frozen-woodland-04787.herokuapp.com/" target="_blank"/> :link:Online demo link:link:<a/>
## ⚙️ General Info
![MONGODB](https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white)![Express.js](https://img.shields.io/badge/Express.js-404D59?style=for-the-badge)![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)![Node.js](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)![Socket.io](https://img.shields.io/badge/Socket.io-DC143C?style=for-the-badge&logo=javascript&logoColor=white)![JS](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)![Redux](https://img.shields.io/badge/Redux-593D88?style=for-the-badge&logo=redux&logoColor=white)![React-router-dom](https://img.shields.io/badge/React_Router-CA4245?style=for-the-badge&logo=react-router&logoColor=white)![Peer](https://img.shields.io/badge/Peer-008B8B?style=for-the-badge&logo=javascript&logoColor=61DAFB)![Redux thunk](https://img.shields.io/badge/Redux_thunk-FF69B4?style=for-the-badge&logo=redux&logoColor=black)![Moment](https://img.shields.io/badge/Moment-FF8C00?style=for-the-badge&logo=javascript&logoColor=black)
 - Node.js, express.js
 - React, React-router-dom
 - Redux, react-redux, redux-thunk
 -  Socket. io, peer

`$ npm run install-all && npm start`
 
 
## 🔥 About project 👀
**Homepage** 🏠

![Homepage]( https://i.ibb.co/PYy1YMQ/Peek-2021-08-17-13-59.gif)

**Messages and Calls** ✉️ 📞

![Messages]( https://i.ibb.co/nbyN557/Peek-2021-08-17-15-06.gif)

**Manage your profile** 🛠️ + 🐬  = 🦈
 
![Profilepage]( https://i.ibb.co/qNbxcLV/Peek-2021-08-17-15-12.gif)

**You need login or register to see...** 🔒

![Authpage]( https://i.ibb.co/Sy2QCky/Peek-2021-08-17-13-54.gif)
# 🔮 In Future ⏳
-  Make it DRY and SOLID 🧹 🧼 🚿
- Add testing of components react and api ☑️
 - Add many emoticons 💥 💯
 - Add support for all file formats 🗃️
